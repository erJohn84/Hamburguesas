//
//  ViewController.swift
//  Hamburguesas
//
//  Created by John Veronelli on 6/18/16.
//  Copyright © 2016 John Veronelli. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let paises = ColeccionDePaises()
    let hamburguesas = ColeccionDeHamburguesa()
    let fondo = ColorPantalla()
    
    @IBOutlet weak var paisLabel: UILabel!
    @IBOutlet weak var hamburguesaLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        paisLabel.text! = paises.obtenPais()
        hamburguesaLabel.text! = hamburguesas.obtenHamburguesa()
        self.view.backgroundColor = fondo.obtenColor()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func cambiarDatos(sender: UIButton){
        paisLabel.text! = paises.obtenPais()
        hamburguesaLabel.text! = hamburguesas.obtenHamburguesa()
        self.view.backgroundColor = fondo.obtenColor()
    }


}

